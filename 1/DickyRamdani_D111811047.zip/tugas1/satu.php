<?php 

$nilai = 60; // deklarasi variabel
if ($nilai >= 50) // logika if else , ini kondisi nya
echo "lulus"; // jika kondisi bernilai true tampil yang ini
else 
echo "Tidak lulus"; // jika kondisi nya false tampil yang ini

?> 